# Creating Single Memorystore for Redis
